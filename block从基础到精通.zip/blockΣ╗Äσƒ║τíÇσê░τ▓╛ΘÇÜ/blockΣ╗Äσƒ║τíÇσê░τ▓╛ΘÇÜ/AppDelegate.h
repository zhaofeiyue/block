//
//  AppDelegate.h
//  block从基础到精通
//
//  Created by 赵飞跃 on 16/9/27.
//  Copyright © 2016年 赵飞跃. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

